# Project title: Tableau-Superstore-Project
## Project Description
this project analyzes various metrics of the Superstore dataset, including adversting budgets, customer returns, and profitability by state and product performance.

## Published Dashboard
You can view the published dashboard here:
https://public.tableau.com/views/Projectfortripletenontableau/profitlosses?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link
